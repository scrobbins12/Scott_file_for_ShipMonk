class shortAnswer:
    def __init__(self, studywin):
##        global cor=0
##        global totq=0
        self.saq=[]
        self.saa=[]
        textfile=open("saquestions.txt", "r")
        for line in textfile:
            data=textfile.split(",,")
            self.saq.append(data[0])
            self.saa.append(data[1])
   
    #ask Mckenna if it is up to a certain amount
    def aq(self, studywin, n):
        cor=0
        totq=0
        Ansb=Button(studywin, Point(200, 400), 100, 100, "See Answer")
        nqb=Button(studywin, Point(400, 200), 100, 100, "Next Question")
        cb=Button(studywin, Point(400,400), 100, 100, "Correct")
        icb=Button(studywin, Point(550, 400), 100, 100, "Incorrect")
        for i in range(n):
            rannum=randrange(0, len(saq))
            q=self.saq[rannum]
            a=self.saa[rannum]
            qprompt=Text(Point(200,600),q)
            qprompt.draw(studywin)
            click=studywin.getMouse()
            while not Ansb.isClicked(click):
                click=studywin.getMouse()
            agiven=Text(Point(200, 200), a)
            agiven.draw(studywin)
            mark=Text(Point(200, 200), "Please mark your answer either correct or incorrect by clicking the buttons.")
            mark.draw(studywin)
            pt=studywin.getMouse()
            while not cb.isClicked and icb.isClicked(pt):
                pt=studywin.getMouse()
            if cb.isClicked(pt):
                cor=cor+1
            pt=studywin.getMouse()
            while not nqb.isClicked(pt):
                pt=studywin.getMouse()
            mark.undraw()
            qprompt.undraw()
            agiven.undraw()
            tot=tot+1
        cb.remove()
        icb.remove()
        qcb.remove()
        Ansb.remove()
        rbox=Text(Point(300,400), "You answered " + str(cor)+ " questions correctly out of " + str(tot) + " .")
        rbox.draw(studywin)
        bb=Button(studywin, Point(200, 200), 100, 100, "Back to \n home screen")
        pab=Button(studywin, Point(400, 200), 100, 100, "Play again")
        pt=studywin.getMouse()
        while not bb.isClicked(pt):
            if pab.isClicked(pt):
                askquestions(self, studwin, n)
        
