from buttonclass import*
from random import randrange
from graphics import*

class trueFalse:
    def __init__(self, studywin):
        
        self.q=[]
        self.a=[]
        textfile=open("tfquestions.txt", "r")
        for line in textfile:
            datalist=line.split(",,")
            print(datalist[0])
            print(datalist[1])
            self.q.append(datalist[0])
            self.a.append(datalist[1])
        
    def at(self, studywin, n):
        cor=0
        totq=0
        trueb=Button(studywin, Point(200, 200), 50, 50, "True")
        falseb=Button(studywin, Point(300, 200), 50, 50, "False")
        nqb=Button(studywin, Point(340, 500), 100, 100, "Next Question")
        for i in range(n):
            rannum=randrange(0,len(self.q))
            question=self.q[rannum]
            qbox=Text(Point(600, 400), question)
            qbox.draw(studywin)
            answer=self.a[rannum]
            click=studywin.getMouse()
            while not falseb.isClicked and not trueb.isClicked (click):
                click=studywin.getMouse()
            if answer==True and trueb.isClicked(click):
                result="correct"
                cor=cor+1
            elif answer==False and falseb.isClicked(click):
                result="correct"
                cor=cor+1
            else:
                result="incorrect"
##            if result=="correct":
####                self.q.pop(question)
####                a.pop(answer)
            resultbox=Text(Point(350, 400), "Your answer is " + result + ".")
            resultbox.draw(studywin)
            pt=studywin.getMouse()

            while not nqb.isClicked(pt):
                pt=studywin.getMouse()
            resultbox.undraw()
            qbox.undraw()
            totq=totq+1
        trueb.remove()
        falseb.remove()
        nqb.remove()
        done=Text(Point(300, 400), "You answered "+ str(cor) + " out of "+ str(totq) + " questions correctly.")
        done.draw(studywin)
        bb=Button(studywin, Point(200, 200), 100, 100, "Back to \n home screen")
        pag=Button(studywin, Point(400, 200), 120, 120, "See more \n True/False/n questions")
        pt=studywin.getMouse()
        while not bb.isClicked(pt):
            if pag.isClicked(pt):
                at(self, studywin, n)
            pt=studywin.getMouse()
def main():
    studywin=GraphWin("Studywin", 800, 800)
    n=4
    tf=trueFalse(studywin)
    tf.at(studywin, n)
main()
    
