#Scott and Claton final COM110 project
from tfclass import*
from shortanswerclass import*
from mcclass import*
from graphics import*


def runintro():
    introwin=GraphWin("Banking Program", 800, 800)
    continuetext=Text(Point(500, 600), "Please click the continue button\
when you would like to move onto \
the game and/or studying the economic concepts.")
    quittext=Text(Point(200,50), "Click the quit button if you would like\
to exit the program.")
    ndb=Button(introwin, Point(250, 200), 75, 75, "Next Direction")
    quittext.draw(introwin)
    tbox=Text(Point(320,400), "")
    tbox.draw(introwin)
    continuetext.draw(introwin)
    dirc=[]
    dirctextfile=open("directions.txt", "r")
    for line in dirctextfile:
        dirc.append(line.split(",,"))
    ndb.activate()
    pqb=Button(introwin, Point(600, 400), 100, 100, "Practice \n Questions now")
    pt=introwin.getMouse()
    i=0
##    prevb=Button(introwin, Point(500, 400), 100, 100, "Previous direction")
##    prevb.deactivate()
    while not pqb.isClicked(pt):
        if ndb.isClicked(pt):
            if i<len(dirc):
                tbox.setText(dirc[i])
            elif i==len(dirc):
                ndb.setLabel("See directions \n again")
                i=0
                moveon=Text(Point(400, 300), "This is your last direction. \
Please \n click the button below to move on.")
                moveon.draw(introwin)
            if i==0:
                ndb.setLabel("See next \n direction")
            i=i+1
        pt=introwin.getMouse()
    introwin.close()
runintro()
        
        
def homescreen():
    studywin=GraphWin("studywin", 800, 800)
    select=Text(Point(200, 300), "Please choose which way you would\
like to study.")
    select.draw(studywin)
    siab=Button(studywin, Point(300, 500), 100, 100, "See intro again")
    lb=Button(studywin, Point(200,500), 100, 100, "Leave program")
    mcb=Button(studywin, Point(200, 200), 100, 100, "Multiple Choice")
    sab=Button(studywin, Point(500, 500), 100, 100, "Short Answer")
    tfb=Button(studywin, Point(350, 350), 100, 100, "True/False")
    direction=Text(Point(300, 100), "Enter the amount of questions\
you want to answer of this type in the entrybox below.")
    direction.draw(studywin)
    numq=Entry(Point(100,100), 10)
    n=numq.getText()
    pt=studywin.getMouse()
    while not lb.isClicked(pt):
        if siab.isClicked(pt):
            runintro()
        if sab.isClicked(pt):
            sac=shortanswerclass(studywin)
            sac.aq(studywin, n)
            #call shortanswerclass
        elif tfb.isClicked(pt):
            tf=trueFalse(studywin)
            tf.at(studywin, n)
            #call true false class
        elif mcb.isClicked(pt):
            much=mchoice()
            much.at(n, studywin)
            #call multiple choice class
        pt=studywin.getMouse()
    studywin.close()
    
def main():
    runintro()
    homescreen()
main()
